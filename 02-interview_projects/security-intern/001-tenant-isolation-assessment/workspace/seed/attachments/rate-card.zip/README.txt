Bellpost rate card sample, 2026-04.
